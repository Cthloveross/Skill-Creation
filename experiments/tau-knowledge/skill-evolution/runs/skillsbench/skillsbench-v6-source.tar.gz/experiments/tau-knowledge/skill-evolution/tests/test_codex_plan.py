"""Offline app-server transport checks: no account or model is contacted."""

import base64
import json
import urllib.request
from pathlib import Path

import pytest
from tau_skill_evolution.codex_plan import CodexPlanClient, CodexPlanOpener, _inputs
from tau_skill_evolution.journal import Journal, UnknownOperation
from tau_skill_evolution.model import ModelClientError


def fake_server(path: Path, *, crash: bool = False, failed: bool = False) -> str:
    program = """#!/usr/bin/python3
import json,sys
count=0
for line in sys.stdin:
 v=json.loads(line); method=v.get('method'); result={}
 if method=='initialized': continue
 if method in ('thread/start','thread/resume'):
  result={'thread':{'id':'thread'},'model':'gpt-6.1-sol','modelProvider':'openai',
   'instructionSources':[],'runtimeWorkspaceRoots':[]}
 if method=='turn/start':
  count+=1
  open(COUNT,'a').write('turn\\n')
  if CRASH: sys.exit(1)
  result={'turn':{'id':str(count)}}
 print(json.dumps({'id':v['id'],'result':result}),flush=True)
 if method=='turn/start':
  print(json.dumps({'method':'thread/tokenUsage/updated','params':{'turnId':str(count),
   'tokenUsage':{'last':{'inputTokens':10,'cachedInputTokens':2,'outputTokens':8,
    'reasoningOutputTokens':3,'totalTokens':18}}}}),flush=True)
  print(json.dumps({'method':'item/completed','params':{'item':{'type':'agentMessage',
   'phase':'final_answer','text':json.dumps({'content':'done','tool_calls':[]})}}}),flush=True)
  print(json.dumps({'method':'turn/completed','params':{'turn':{'id':str(count),
   'status':'failed' if FAILED else 'completed'}}}),flush=True)
"""
    path.write_text(
        f"#!/usr/bin/python3\nCOUNT={str(path.with_suffix('.count'))!r}\nCRASH={crash!r}\nFAILED={failed!r}\n"
        + program.split("\n", 1)[1]
    )
    path.chmod(0o700)
    return str(path)


def test_single_turn_raw_sealed_and_recovery(tmp_path):
    binary = fake_server(tmp_path / "codex")
    settings = dict(
        role="generator",
        journal_dir=tmp_path / "private",
        binary=binary,
        usage_path=tmp_path / "usage.jsonl",
    )
    client = CodexPlanClient(**settings)
    messages = [{"role": "user", "content": "create"}]
    try:
        first = client.complete(messages)
        assert first["content"] == "done"
        assert first["usage"]["output_tokens_details"]["reasoning_tokens"] == 3
    finally:
        client.close()
    recovered = CodexPlanClient(**settings)
    try:
        assert recovered.complete(messages) == first
        assert recovered._process is None
    finally:
        recovered.close()
    assert (tmp_path / "codex.count").read_text() == "turn\n"
    record = next((tmp_path / "private").glob("*/raw-response.json"))
    raw = json.loads(base64.b64decode(json.loads(record.read_text())["body_base64"]))
    assert raw["thread_id"] == "thread" and raw["turn_id"] == "1"
    assert any(e.get("method") == "turn/completed" for e in raw["events"])


def test_unknown_never_redispatched(tmp_path):
    binary = fake_server(tmp_path / "codex", crash=True)
    settings = dict(role="generator", journal_dir=tmp_path / "private", binary=binary)
    messages = [{"role": "user", "content": "create"}]
    first = CodexPlanClient(**settings)
    try:
        with pytest.raises(UnknownOperation):
            first.complete(messages)
    finally:
        first.close()
    again = CodexPlanClient(**settings)
    try:
        with pytest.raises(UnknownOperation):
            again.complete(messages)
        with pytest.raises(UnknownOperation):
            again.complete([{"role": "user", "content": "different request"}])
        assert again._process is None
    finally:
        again.close()
    assert (tmp_path / "codex.count").read_text() == "turn\n"


def test_delta_and_role_binding(tmp_path):
    client = CodexPlanClient(role="generator", journal_dir=tmp_path / "private")
    requests = []
    events = []
    client._start = lambda: None

    def rpc(method, params):
        requests.append((method, params))
        if method == "thread/start":
            return {
                "thread": {"id": "isolated"},
                "model": "gpt-6.1-sol",
                "modelProvider": "openai",
                "instructionSources": [],
                "runtimeWorkspaceRoots": [],
            }
        if method == "thread/resume":
            return {
                "model": "gpt-6.1-sol",
                "modelProvider": "openai",
                "instructionSources": [],
                "runtimeWorkspaceRoots": [],
            }
        if method == "turn/start":
            events[:] = [{"method": "turn/completed", "params": {"turn": {"id": "a"}}}]
            return {"turn": {"id": "a"}}
        return {}

    client._rpc = rpc
    client._read = lambda _: events.pop()
    original = [{"role": "user", "content": "fixed base"}]
    client._turn(client._ready({"messages": original, "tools": []}))
    client.state["messages"] = original
    client._turn(
        client._ready(
            {"messages": original + [{"role": "user", "content": "new feedback"}], "tools": []}
        )
    )
    turns = [params for method, params in requests if method == "turn/start"]
    assert len(turns) == 2
    assert json.loads(turns[1]["input"][0]["text"])["messages"] == [
        {"role": "user", "content": "new feedback"}
    ]
    assert turns[0]["environments"] == []
    frame = next(params for method, params in requests if method == "thread/start")
    assert frame["sandbox"] == "read-only"
    assert frame["dynamicTools"] == []
    assert "separate task container" in frame["baseInstructions"]
    assert "write task deliverables" in frame["baseInstructions"]
    assert "only your native host capabilities" in frame["baseInstructions"]
    with pytest.raises(ValueError, match="identity"):
        CodexPlanClient(role="verifier", journal_dir=tmp_path / "private")


def test_outer_journal_and_known_failed_turn(tmp_path):
    client = CodexPlanClient(
        role="generator",
        journal_dir=tmp_path / "private",
        binary=fake_server(tmp_path / "codex", failed=True),
    )
    journal = Journal(tmp_path / "outer")
    try:
        with pytest.raises(ModelClientError, match="did not complete"):
            client.complete_journaled(journal, "s0", {}, [{"role": "user", "content": "create"}])
    finally:
        client.close()
    assert (tmp_path / "codex.count").read_text() == "turn\n"


def test_native_relay_function_custom_and_namespaced_calls(tmp_path):
    client = CodexPlanClient(role="execution", journal_dir=tmp_path / "private")
    calls = [
        ("read", '{"path":"a"}'),
        ("apply_patch", "*** patch"),
        ("functions.exec_command", '{"cmd":"true"}'),
    ]
    client.complete = lambda *args, **kwargs: {
        "content": "ready",
        "response_id": "turn",
        "usage": {"input_tokens": 10, "output_tokens": 5},
        "tool_calls": [
            {"id": str(i), "function": {"name": name, "arguments": arguments}}
            for i, (name, arguments) in enumerate(calls)
        ],
    }
    payload = {
        "input": [{"role": "user", "content": "task"}],
        "tools": [
            {"type": "function", "name": "read"},
            {"type": "custom", "name": "apply_patch"},
            {
                "type": "namespace",
                "name": "functions",
                "tools": [{"type": "function", "name": "exec_command"}],
            },
        ],
    }
    opener = CodexPlanOpener(client)
    request = urllib.request.Request("http://unused/responses", data=json.dumps(payload).encode())
    with opener(request, timeout=15) as response:
        result = json.loads(response.read())
    assert result["output"][1]["type"] == "function_call"
    assert result["output"][2]["type"] == "custom_tool_call"
    assert result["output"][2]["input"] == "*** patch"
    assert result["output"][3]["namespace"] == "functions"
    assert result["output"][3]["name"] == "exec_command"
    assert client.timeout_seconds == 300


def test_startup_is_unsent_and_does_not_block_new_credential_attempt(tmp_path):
    script = tmp_path / "closed-server"
    script.write_text("#!/usr/bin/python3\nimport sys\nsys.exit(1)\n")
    script.chmod(0o700)
    client = CodexPlanClient(role="generator", journal_dir=tmp_path / "private", binary=str(script))
    outer = Journal(tmp_path / "outer")
    try:
        with pytest.raises(EOFError):
            client.complete_journaled(outer, "s0", {}, [{"role": "user", "content": "create"}])
        assert outer.status("s0") == "NOT_SENT"
        assert not client.blocked_path.exists()
    finally:
        client.close()


@pytest.mark.parametrize(
    "name,raw,kind",
    [
        ("exec", "await tools.exec_command({cmd: 'pwd'})", "custom_tool_call"),
        ("wait", "{cell_id: 'cell', yield_time_ms: 1000}", "custom_tool_call"),
        ("apply_patch", "*** Begin Patch\n*** End Patch", "custom_tool_call"),
        ("exec_command", '{"cmd":"pwd"}', "function_call"),
    ],
)
def test_pinned_cli_prompt_declared_tools_without_tools_field(tmp_path, name, raw, kind):
    client = CodexPlanClient(role="execution", journal_dir=tmp_path / "private")
    client.complete = lambda *args, **kwargs: {
        "content": "",
        "response_id": "turn",
        "usage": {"input_tokens": 5, "output_tokens": 10},
        "tool_calls": [{"id": "call", "function": {"name": "functions." + name, "arguments": raw}}],
    }
    payload = {
        "input": [
            {"role": "developer", "content": "Namespace: functions"},
            {"role": "user", "content": "task"},
        ]
    }
    request = urllib.request.Request("http://unused/responses", data=json.dumps(payload).encode())
    with CodexPlanOpener(client)(request, timeout=15) as response:
        item = json.loads(response.read())["output"][0]
    assert item["type"] == kind
    assert item["namespace"] == "functions"
    assert item["name"] == name
    assert item["input" if kind == "custom_tool_call" else "arguments"] == raw


def test_model_or_host_instruction_mismatch_blocks_before_turn(tmp_path):
    client = CodexPlanClient(role="generator", journal_dir=tmp_path / "private")
    client._start = lambda: None
    client._rpc = lambda *args: {
        "thread": {"id": "wrong"},
        "model": "other",
        "modelProvider": "openai",
    }
    with pytest.raises(ModelClientError, match="mismatch"):
        client._ready({"messages": []})
    client._rpc = lambda *args: {
        "thread": {"id": "wrong"},
        "model": client.model,
        "modelProvider": "openai",
        "instructionSources": ["/private/AGENTS.md"],
    }
    with pytest.raises(ModelClientError, match="unexpected host"):
        client._ready({"messages": [{"role": "user", "content": "new"}]})


def test_task_image_uses_native_input_without_host_file_access():
    source = [
        {
            "role": "user",
            "content": [
                {"type": "input_image", "image_url": "data:image/png;base64,AA==", "detail": "high"}
            ],
        }
    ]
    actual = _inputs(source, [], None)
    assert actual[1] == {"type": "image", "url": "data:image/png;base64,AA==", "detail": "high"}
    assert "base64" not in actual[0]["text"]
    assert source[0]["content"][0]["type"] == "input_image"
    with pytest.raises(ModelClientError, match="inline task"):
        _inputs([{"type": "input_image", "image_url": "file:///private/auth.json"}], [], None)
    with pytest.raises(ModelClientError, match="unsupported"):
        _inputs([{"type": "input_audio", "data": "abc"}], [], None)
